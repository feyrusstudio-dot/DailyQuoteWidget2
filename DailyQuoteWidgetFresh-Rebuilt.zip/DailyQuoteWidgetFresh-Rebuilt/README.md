# DailyQuoteWidgetFresh
- D-Day/calendar tab: set goal title and target date; displays D- / D-Day / D+.
- Quote management: add/edit/delete, 10 items per page, bulk add, clipboard backup/restore, background cycling.
- Android home widgets: random quote widget (tap to reroll) and D-Day widget.
- App updates widget data when quotes/date/title are changed.

Build using GitHub Actions workflow `build-apk.yml` or `gradle assembleDebug` with Android SDK installed.
