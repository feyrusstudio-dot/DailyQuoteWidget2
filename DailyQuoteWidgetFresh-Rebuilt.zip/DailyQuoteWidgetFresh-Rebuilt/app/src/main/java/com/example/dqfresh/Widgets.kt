package com.example.dqfresh

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object WidgetData {
    const val PREFS = "data"
    const val SEP = "\u001e"
    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun refreshAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        QuoteWidgetProvider.update(context, manager, manager.getAppWidgetIds(ComponentName(context, QuoteWidgetProvider::class.java)))
        DDayWidgetProvider.update(context, manager, manager.getAppWidgetIds(ComponentName(context, DDayWidgetProvider::class.java)))
    }
}

class QuoteWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_RANDOM) {
            val mgr = AppWidgetManager.getInstance(context)
            update(context, mgr, mgr.getAppWidgetIds(ComponentName(context, QuoteWidgetProvider::class.java)), forceNew = true)
        }
    }
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context, manager, ids)
    companion object {
        const val ACTION_RANDOM = "com.example.dqfresh.RANDOM_QUOTE"
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray, forceNew: Boolean = false) {
            if (ids.isEmpty()) return
            val prefs = WidgetData.prefs(context)
            val quotes = (prefs.getString("q", "") ?: "").split(WidgetData.SEP).filter { it.isNotBlank() }
            val last = prefs.getInt("widget_quote_index", -1)
            val pick = if (quotes.isEmpty()) -1 else if (quotes.size == 1) 0 else quotes.indices.filter { it != last }.random()
            if (pick >= 0 && (forceNew || pick != last)) prefs.edit().putInt("widget_quote_index", pick).apply()
            val selectedIndex = if (pick >= 0) pick else last.takeIf { it in quotes.indices } ?: -1
            val quote = if (selectedIndex in quotes.indices) quotes[selectedIndex] else "앱에서 문장을 추가하세요"
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_quote)
                views.setTextViewText(R.id.widget_quote_text, quote)
                val intent = Intent(context, QuoteWidgetProvider::class.java).setAction(ACTION_RANDOM)
                val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.quote_widget_root, pending)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
class DDayWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context, manager, ids)
    companion object {
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            if (ids.isEmpty()) return
            val p = WidgetData.prefs(context)
            val title = p.getString("title", "목표 날짜") ?: "목표 날짜"
            val dateText = p.getString("date", "") ?: ""
            val count = try {
                val parser = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).apply { isLenient = false }
                val date = parser.parse(dateText) ?: error("invalid date")
                val target = Calendar.getInstance().apply { time = date; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                val days = (target.timeInMillis - today.timeInMillis) / 86400000L
                when { days > 0 -> "D-$days"; days == 0L -> "D-Day"; else -> "D+${-days}" }
            } catch (_: Exception) { "날짜 설정 필요" }
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget_dday)
                views.setTextViewText(R.id.widget_dday_title, title)
                views.setTextViewText(R.id.widget_dday_count, count)
                views.setTextViewText(R.id.widget_dday_date, dateText.ifBlank { "앱에서 날짜 설정" })
                val launch = Intent(context, MainActivity::class.java)
                val pending = PendingIntent.getActivity(context, id, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.dday_widget_root, pending)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
