package com.example.dqfresh

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(WidgetData.PREFS, MODE_PRIVATE) }
    private val quotes = mutableListOf<String>()
    private var page = 0
    private val pageSize = 10
    private var tab = 0
    private lateinit var root: LinearLayout
    private val bgOptions = intArrayOf(Color.WHITE, Color.rgb(255,247,232), Color.rgb(232,243,255), Color.rgb(238,246,235))
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); loadQuotes(); showScreen() }
    private fun loadQuotes() { quotes.clear(); (prefs.getString("q", "") ?: "").takeIf { it.isNotEmpty() }?.let { quotes.addAll(it.split(WidgetData.SEP).filter(String::isNotBlank)) } }
    private fun saveQuotes() { prefs.edit().putString("q", quotes.joinToString(WidgetData.SEP)).apply(); WidgetData.refreshAll(this) }
    private fun makeRoot(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,16,16,10); setBackgroundColor(bgOptions[prefs.getInt("bg",0).coerceIn(bgOptions.indices)]) }
        val heading = TextView(this).apply { text = title; textSize = 24f; setTextColor(Color.BLACK); setPadding(4,4,4,14) }
        root.addView(heading); return root
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun tabBar() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("📅 D-Day / 달력") { tab = 0; showScreen() }, LinearLayout.LayoutParams(0,-2,1f))
        row.addView(button("📝 문장 관리") { tab = 1; showScreen() }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row)
    }
    private fun showScreen() { if (tab == 0) showDay() else showQuotes() }
    private fun showDay() {
        val r = makeRoot("D-Day / 달력 설정")
        val title = prefs.getString("title", "목표 날짜") ?: "목표 날짜"
        val date = prefs.getString("date", "") ?: ""
        r.addView(TextView(this).apply { text = "$title\n${date.ifBlank { "날짜 미설정" }}"; textSize=19f; setTextColor(Color.BLACK); setPadding(8,12,8,18 })
        r.addView(button("목표 이름 변경") { editText("목표 이름", title) { prefs.edit().putString("title",it).apply(); WidgetData.refreshAll(this); showDay() } })
        r.addView(button("날짜 선택") { val c=Calendar.getInstance(); DatePickerDialog(this,{_,y,m,d-> prefs.edit().putString("date",String.format("%04d-%02d-%02d",y,m+1,d)).apply(); WidgetData.refreshAll(this); showDay() },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() })
        r.addView(button("위젯 새로고침") { WidgetData.refreshAll(this); Toast.makeText(this,"위젯 갱신 완료",Toast.LENGTH_SHORT).show() })
        tabBar(); setContentView(r)
    }
    private fun showQuotes() {
        loadQuotes()
        val r = makeRoot("문장 관리 (${quotes.size}개)")
        val pages = ((quotes.size + pageSize - 1) / pageSize).coerceAtLeast(1); page = page.coerceIn(0,pages-1)
        val pager = LinearLayout(this).apply { gravity=Gravity.CENTER; orientation=LinearLayout.HORIZONTAL }
        pager.addView(button("◀") { page=(page-1).coerceAtLeast(0); showQuotes() })
        pager.addView(TextView(this).apply { text=" ${page+1} / $pages "; textSize=16f; setTextColor(Color.BLACK); gravity=Gravity.CENTER; setPadding(8,12,8,12 })
        pager.addView(button("▶") { page=(page+1).coerceAtMost(pages-1); showQuotes() }); r.addView(pager)
        val scroll = ScrollView(this); val list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        for (i in page*pageSize until minOf((page+1)*pageSize,quotes.size)) {
            val item = TextView(this).apply { text="${i+1}. ${quotes[i]}"; textSize=16f; setTextColor(Color.BLACK); setPadding(8,12,8,12) }
            item.setOnClickListener { editText("문장 수정",quotes[i]) { quotes[i]=it; saveQuotes(); showQuotes() } }
            item.setOnLongClickListener { AlertDialog.Builder(this).setMessage("${i+1}번 문장을 삭제할까요?").setPositiveButton("삭제") { _,_-> quotes.removeAt(i); page=page.coerceAtMost(((quotes.size+pageSize-1)/pageSize).coerceAtLeast(1)-1); saveQuotes(); showQuotes() }.setNegativeButton("취소",null).show(); true }
            list.addView(item); list.addView(View(this).apply { setBackgroundColor(0x22000000); layoutParams=LinearLayout.LayoutParams(-1,1) })
        }
        scroll.addView(list); r.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        r.addView(button("문장 추가") { editText("새 문장","") { text -> if(text.isNotBlank()){quotes.add(text);saveQuotes();page=(quotes.size-1)/pageSize;showQuotes()} } })
        r.addView(button("여러 문장 한꺼번에 추가") { val input=EditText(this).apply { hint="한 줄에 문장 하나씩"; minLines=5 }; AlertDialog.Builder(this).setTitle("일괄 추가").setView(input).setPositiveButton("추가") { _,_-> val added=input.text.lines().map(String::trim).filter(String::isNotBlank); quotes.addAll(added); if(added.isNotEmpty()){saveQuotes();page=(quotes.size-1)/pageSize};showQuotes() }.setNegativeButton("취소",null).show() })
        r.addView(button("백업 / 복원") { backupRestore() })
        r.addView(button("배경색 변경") { val next=(prefs.getInt("bg",0)+1)%bgOptions.size; prefs.edit().putInt("bg",next).apply(); showQuotes() })
        r.addView(button("위젯 갱신") { WidgetData.refreshAll(this); Toast.makeText(this,"위젯 갱신 완료",Toast.LENGTH_SHORT).show() })
        tabBar(); setContentView(r)
    }
    private fun editText(title:String, initial:String, done:(String)->Unit) { val edit=EditText(this).apply { setText(initial) }; AlertDialog.Builder(this).setTitle(title).setView(edit).setPositiveButton("저장") { _,_->done(edit.text.toString().trim()) }.setNegativeButton("취소",null).show() }
    private fun backupRestore() {
        val options=arrayOf("백업 복사","텍스트에서 복원")
        AlertDialog.Builder(this).setTitle("백업 / 복원").setItems(options) { _,which ->
            if(which==0){ val text=quotes.joinToString("\n"); val clipboard=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager; clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Daily Quote backup",text)); Toast.makeText(this,"문장 백업을 클립보드에 복사했습니다",Toast.LENGTH_SHORT).show() }
            else { val input=EditText(this).apply { hint="한 줄에 문장 하나씩"; minLines=5 }; AlertDialog.Builder(this).setTitle("복원할 문장 붙여넣기").setView(input).setPositiveButton("복원") { _,_-> val restored=input.text.lines().map(String::trim).filter(String::isNotBlank); if(restored.isNotEmpty()){quotes.clear();quotes.addAll(restored);page=0;saveQuotes();showQuotes()} }.setNegativeButton("취소",null).show() }
        }.show()
    }
}
