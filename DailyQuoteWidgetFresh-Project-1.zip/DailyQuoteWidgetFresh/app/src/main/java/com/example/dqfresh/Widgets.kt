package com.example.dqfresh

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

object WidgetData {
    const val PREFS = "data"
    const val SEP = "\u001e"

    fun refreshAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val quoteIds = manager.getAppWidgetIds(ComponentName(context, QuoteWidgetProvider::class.java))
        if (quoteIds.isNotEmpty()) QuoteWidgetProvider.update(context, manager, quoteIds, chooseNew = true)
        val dayIds = manager.getAppWidgetIds(ComponentName(context, DDayWidgetProvider::class.java))
        if (dayIds.isNotEmpty()) DDayWidgetProvider.update(context, manager, dayIds)
    }


    fun chooseQuote(context: Context, forceNew: Boolean): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val quotes = (prefs.getString("q", "") ?: "").split(SEP).filter { it.isNotBlank() }
        if (quotes.isEmpty()) return "앱에서 문장을 추가하세요"
        val previous = prefs.getInt("widget_quote_index", -1)
        val next = if (quotes.size == 1) 0 else quotes.indices.filter { it != previous }.random()
        prefs.edit().putInt("widget_quote_index", next).apply()
        return quotes[next]
    }
}


class QuoteWidgetProvider : AppWidgetProvider() {
    companion object {
        const val ACTION_RANDOM = "com.example.dqfresh.ACTION_RANDOM_QUOTE"

        fun update(context: Context, manager: AppWidgetManager, ids: IntArray, chooseNew: Boolean) {
            if (ids.isEmpty()) return
            val prefs = context.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE)
            val quotes = (prefs.getString("q", "") ?: "").split(WidgetData.SEP).filter { it.isNotBlank() }
            val previous = prefs.getInt("widget_quote_index", -1)
            val selected = if (quotes.isEmpty()) -1 else if (quotes.size == 1) 0 else {
                if (chooseNew || previous !in quotes.indices) quotes.indices.filter { it != previous }.random() else previous
            }
            if (selected >= 0) prefs.edit().putInt("widget_quote_index", selected).apply()
            val text = if (selected >= 0) quotes[selected] else "앱에서 문장을 추가하세요"
            ids.forEach { widgetId ->
                val views = RemoteViews(context.packageName, R.layout.widget_quote)
                views.setTextViewText(R.id.widget_quote_text, text)
                val click = Intent(context, QuoteWidgetProvider::class.java).apply { action = ACTION_RANDOM }
                val pending = PendingIntent.getBroadcast(context, widgetId, click, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.quote_widget_root, pending)
                manager.updateAppWidget(widgetId, views)
            }
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        update(context, manager, ids, chooseNew = true)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_RANDOM) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, QuoteWidgetProvider::class.java))
            update(context, manager, ids, chooseNew = true)
        }
    }
}


class DDayWidgetProvider : AppWidgetProvider() {
    companion object {
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            if (ids.isEmpty()) return
            val prefs = context.getSharedPreferences(WidgetData.PREFS, Context.MODE_PRIVATE)
            val title = prefs.getString("title", "목표 날짜") ?: "목표 날짜"
            val dateText = prefs.getString("date", "") ?: ""
            val result = try {
                val parser = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).apply { isLenient = false; timeZone = TimeZone.getTimeZone("UTC") }
                val parsed = parser.parse(dateText) ?: throw IllegalArgumentException("date")
                val target = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { time = parsed }
                val today = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                val dayDiff = ((target.timeInMillis - today.timeInMillis) / 86400000L)
                when {
                    dayDiff > 0 -> "D-$dayDiff"
                    dayDiff == 0L -> "D-Day"
                    else -> "D+${-dayDiff}"
                }
            } catch (_: Exception) { "날짜 설정 필요" }
            ids.forEach { widgetId ->
                val views = RemoteViews(context.packageName, R.layout.widget_dday)
                views.setTextViewText(R.id.widget_dday_title, title)
                views.setTextViewText(R.id.widget_dday_count, result)
                views.setTextViewText(R.id.widget_dday_date, dateText.ifBlank { "앱에서 날짜 설정" })
                val openApp = Intent(context, MainActivity::class.java)
                val pending = PendingIntent.getActivity(context, widgetId + 10000, openApp, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.dday_widget_root, pending)
                manager.updateAppWidget(widgetId, views)
            }
        }
    }


    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context, manager, ids)
}
