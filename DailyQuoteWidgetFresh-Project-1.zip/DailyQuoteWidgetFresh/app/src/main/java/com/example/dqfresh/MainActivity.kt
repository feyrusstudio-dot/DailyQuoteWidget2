package com.example.dqfresh

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(WidgetData.PREFS, MODE_PRIVATE) }
    private val quotes = mutableListOf<String>()
    private var page = 0
    private val pageSize = 10
    private var selectedTab = 0
    private val backgrounds = intArrayOf(Color.WHITE, 0xFFFFF7E8.toInt(), 0xFFE8F3FF.toInt(), 0xFFEEF6EB.toInt())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadQuotes()
        showScreen()
    }

    override fun onResume() {
        super.onResume()
        loadQuotes()
    }

    private fun loadQuotes() {
        quotes.clear()
        val stored = prefs.getString("q", "") ?: ""
        if (stored.isNotBlank()) quotes.addAll(stored.split(WidgetData.SEP).filter { it.isNotBlank() })
    }

    private fun saveQuotes() {
        prefs.edit().putString("q", quotes.joinToString(WidgetData.SEP)).apply()
        WidgetData.refreshAll(this)
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
    }

    private fun makeRoot(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 10)
            setBackgroundColor(backgrounds[prefs.getInt("bg", 0).coerceIn(backgrounds.indices)])
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 23f
            setTextColor(Color.BLACK)
            setPadding(4, 4, 4, 12)
        }
        root.addView(heading)
        return root
    }

    private fun addTabs(root: LinearLayout) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("D-Day / 날짜") { selectedTab = 0; showScreen() }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(button("문장 관리") { selectedTab = 1; showScreen() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
    }

    private fun showScreen() {
        if (selectedTab == 0) showDayScreen() else showQuoteScreen()
    }

    private fun showDayScreen() {
        val root = makeRoot("D-Day / 날짜 설정")
        val title = prefs.getString("title", "목표 날짜") ?: "목표 날짜"
        val date = prefs.getString("date", "") ?: ""
        val info = TextView(this).apply {
            text = "$title\n${date.ifBlank { "날짜 미설정" }}"
            textSize = 20f
            setTextColor(Color.BLACK)
            setPadding(8, 16, 8, 20)
        }
        root.addView(info)
        root.addView(button("목표 이름 설정") { editText("목표 이름", title) { newTitle ->
            prefs.edit().putString("title", newTitle.ifBlank { "목표 날짜" }).apply()
            WidgetData.refreshAll(this)
            showDayScreen()
        } })
        root.addView(button("날짜 선택") {
            val calendar = Calendar.getInstance()
            if (date.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                val parts = date.split("-").map { it.toInt() }
                calendar.set(parts[0], parts[1] - 1, parts[2])
            }
            DatePickerDialog(this, { _, year, month, day ->
                val formatted = String.format("%04d-%02d-%02d", year, month + 1, day)
                prefs.edit().putString("date", formatted).apply()
                WidgetData.refreshAll(this)
                showDayScreen()
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        })
        root.addView(button("위젯 갱신") { WidgetData.refreshAll(this); Toast.makeText(this, "위젯 갱신", Toast.LENGTH_SHORT).show() })
        addTabs(root)
        setContentView(root)
    }


    private fun showQuoteScreen() {
        loadQuotes()
        val root = makeRoot("문장 관리 · ${quotes.size}개")
        val pageCount = ((quotes.size + pageSize - 1) / pageSize).coerceAtLeast(1)
        page = page.coerceIn(0, pageCount - 1)

        val pageBar = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        pageBar.addView(button("◀") { page = (page - 1).coerceAtLeast(0); showQuoteScreen() })
        pageBar.addView(TextView(this).apply {
            text = " ${page + 1} / $pageCount "
            textSize = 16f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(8, 10, 8, 10)
        })
        pageBar.addView(button("▶") { page = (page + 1).coerceAtMost(pageCount - 1); showQuoteScreen() })
        root.addView(pageBar)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val from = page * pageSize
        val to = minOf(from + pageSize, quotes.size)
        for (index in from until to) {
            val item = TextView(this).apply {
                text = "${index + 1}. ${quotes[index]}"
                textSize = 16f
                setTextColor(Color.BLACK)
                setPadding(8, 12, 8, 12)
            }
            item.setOnClickListener { editText("문장 수정", quotes[index]) { edited ->
                if (edited.isNotBlank()) quotes[index] = edited
                saveQuotes(); showQuoteScreen()
            } }
            item.setOnLongClickListener {
                AlertDialog.Builder(this).setMessage("${index + 1}번 문장을 삭제할까요?")
                    .setPositiveButton("삭제") { _, _ ->
                        quotes.removeAt(index)
                        page = page.coerceAtMost(((quotes.size + pageSize - 1) / pageSize).coerceAtLeast(1) - 1)
                        saveQuotes(); showQuoteScreen()
                    }.setNegativeButton("취소", null).show()
                true
            }
            list.addView(item)
            list.addView(View(this).apply { setBackgroundColor(0x22000000); layoutParams = LinearLayout.LayoutParams(-1, 1) })
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(button("문장 추가") { editText("새 문장", "") { added ->
            if (added.isNotBlank()) { quotes.add(added); saveQuotes(); page = (quotes.size - 1) / pageSize }
            showQuoteScreen()
        } })
        root.addView(button("여러 문장 한꺼번에 추가") {
            val input = EditText(this).apply { hint = "한 줄에 문장 하나씩"; minLines = 5 }
            AlertDialog.Builder(this).setTitle("일괄 추가").setView(input)
                .setPositiveButton("추가") { _, _ ->
                    val additions = input.text.lines().map { it.trim() }.filter { it.isNotBlank() }
                    quotes.addAll(additions)
                    if (additions.isNotEmpty()) { saveQuotes(); page = (quotes.size - 1) / pageSize }
                    showQuoteScreen()
                }.setNegativeButton("취소", null).show()
        })
        root.addView(button("백업 / 복원") { backupRestore() })
        root.addView(button("배경색 변경") { prefs.edit().putInt("bg", (prefs.getInt("bg", 0) + 1) % backgrounds.size).apply(); showQuoteScreen() })
        root.addView(button("위젯 갱신") { WidgetData.refreshAll(this); Toast.makeText(this, "위젯 갱신 완료", Toast.LENGTH_SHORT).show() })
        addTabs(root)
        setContentView(root)
    }

    private fun editText(title: String, initial: String, complete: (String) -> Unit) {
        val field = EditText(this).apply { setText(initial) }
        AlertDialog.Builder(this).setTitle(title).setView(field)
            .setPositiveButton("저장") { _, _ -> complete(field.text.toString().trim()) }
            .setNegativeButton("취소", null).show()
    }

    private fun backupRestore() {
        val options = arrayOf("백업 복사", "텍스트에서 복원")
        AlertDialog.Builder(this).setTitle("백업 / 복원").setItems(options) { _, selected ->
            if (selected == 0) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Daily Quote backup", quotes.joinToString("\n")))
                Toast.makeText(this, "문장을 클립보드에 백업했습니다", Toast.LENGTH_SHORT).show()
            } else {
                val field = EditText(this).apply { hint = "한 줄에 문장 하나씩"; minLines = 5 }
                AlertDialog.Builder(this).setTitle("복원할 문장 붙여넣기").setView(field)
                    .setPositiveButton("복원") { _, _ ->
                        val restored = field.text.lines().map { it.trim() }.filter { it.isNotBlank() }
                        if (restored.isNotEmpty()) { quotes.clear(); quotes.addAll(restored); page = 0; saveQuotes(); showQuoteScreen() }
                    }.setNegativeButton("취소", null).show()
            }
        }.show()
    }
}
