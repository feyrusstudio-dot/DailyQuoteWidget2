# DailyQuoteWidgetFresh

Android app (native Kotlin) with two home-screen widgets.

## Features
- D-Day title/date setup in the app; D-Day, D+Day, or D-n displayed on the home widget.
- Quote manager with 10-item pagination, add/edit/delete, bulk add, clipboard backup/restore, and background color options.
- Quote widget selects a random saved quote when refreshed; tapping the quote widget requests another random quote. App-side quote changes refresh installed widgets.
- Shared preferences persist app/widget data.

## Build
This repository is intended for the provided GitHub Actions workflow, which extracts this ZIP and runs `gradle assembleDebug`.

## Validation status
ZIP structure, XML syntax, manifest widget receiver declarations, provider metadata/layout references, and widget resource ID references were statically checked. An Android SDK was not available in the authoring environment, so APK compilation and launcher widget discovery on a physical device remain unverified.
