package com.example.dqfresh

import android.appwidget.AppWidgetProvider
import android.appwidget.AppWidgetManager
import android.content.Context
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class QuoteWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("data", Context.MODE_PRIVATE)
        val raw = prefs.getString("q", "") ?: ""
        val quotes = raw.split("\u001e").filter { it.isNotBlank() }
        val quote = if (quotes.isEmpty()) "앱에서 문장을 추가하세요" else quotes[(prefs.getInt("widget_quote_index", 0) % quotes.size)]
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_quote)
            views.setTextViewText(R.id.widget_quote_text, quote)
            manager.updateAppWidget(id, views)
        }
    }
}


class DDayWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("data", Context.MODE_PRIVATE)
        val title = prefs.getString("title", "목표 날짜") ?: "목표 날짜"
        val dateText = prefs.getString("date", "") ?: ""
        val result = try {
            val parser = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
            parser.isLenient = false
            val targetDate = parser.parse(dateText) ?: throw IllegalArgumentException()
            val target = Calendar.getInstance().apply { time = targetDate; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val diff = ((target.timeInMillis - today.timeInMillis) / 86400000L)
            when {
                diff > 0 -> "D-$diff"
                diff == 0L -> "D-Day"
                else -> "D+${-diff}"
            }
        } catch (_: Exception) { "날짜를 앱에서 설정하세요" }
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_dday)
            views.setTextViewText(R.id.widget_dday_title, title)
            views.setTextViewText(R.id.widget_dday_count, result)
            views.setTextViewText(R.id.widget_dday_date, dateText)
            manager.updateAppWidget(id, views)
        }
    }
}


object WidgetRefresh {
    fun refresh(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val quoteIds = manager.getAppWidgetIds(android.content.ComponentName(context, QuoteWidgetProvider::class.java))
        QuoteWidgetProvider().onUpdate(context, manager, quoteIds)
        val ddayIds = manager.getAppWidgetIds(android.content.ComponentName(context, DDayWidgetProvider::class.java))
        DDayWidgetProvider().onUpdate(context, manager, ddayIds)
    }
}
