package com.example.dqfresh

import android.appwidget.AppWidgetProvider
import android.appwidget.AppWidgetManager
import android.content.Context
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class QuoteWidgetProvider : AppWidgetProvider() {
    companion object {
        const val ACTION_RANDOM_QUOTE = "com.example.dqfresh.ACTION_RANDOM_QUOTE"
    }

    override fun onReceive(context: Context, intent: android.content.Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_RANDOM_QUOTE) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, QuoteWidgetProvider::class.java))
            onUpdate(context, manager, ids)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        if (ids.isEmpty()) return
        val prefs = context.getSharedPreferences("data", Context.MODE_PRIVATE)
        val raw = prefs.getString("q", "") ?: ""
        val quotes = raw.split("\u001e").filter { it.isNotBlank() }
        val previous = prefs.getInt("widget_quote_index", -1)
        val selected = when {
            quotes.isEmpty() -> -1
            quotes.size == 1 -> 0
            else -> quotes.indices.filter { it != previous }.random()
        }
        if (selected >= 0) prefs.edit().putInt("widget_quote_index", selected).apply()
        val quote = if (selected < 0) "앱에서 문장을 추가하세요" else quotes[selected]
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_quote)
            views.setTextViewText(R.id.widget_quote_text, quote)
            val clickIntent = android.content.Intent(context, QuoteWidgetProvider::class.java).apply {
                action = ACTION_RANDOM_QUOTE
            }
            val pending = android.app.PendingIntent.getBroadcast(
                context, id, clickIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_quote_text, pending)
            manager.updateAppWidget(id, views)
        }
    }
}

class DDayWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("data", Context.MODE_PRIVATE)
        val title = prefs.getString("title", "목표 날짜") ?: "목표 날짜"
        val dateText = prefs.getString("date", "") ?: ""
        val result = try {
            val parser = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA)
            parser.isLenient = false
            val targetDate = parser.parse(dateText) ?: throw IllegalArgumentException()
            val target = Calendar.getInstance().apply { time = targetDate; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val diff = ((target.timeInMillis - today.timeInMillis) / 86400000L)
            when {
                diff > 0 -> "D-$diff"
                diff == 0L -> "D-Day"
                else -> "D+${-diff}"
            }
        } catch (_: Exception) { "날짜를 앱에서 설정하세요" }
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.widget_dday)
            views.setTextViewText(R.id.widget_dday_title, title)
            views.setTextViewText(R.id.widget_dday_count, result)
            views.setTextViewText(R.id.widget_dday_date, dateText)
            manager.updateAppWidget(id, views)
        }
    }
}


object WidgetRefresh {
    fun refresh(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val quoteIds = manager.getAppWidgetIds(android.content.ComponentName(context, QuoteWidgetProvider::class.java))
        QuoteWidgetProvider().onUpdate(context, manager, quoteIds)
        val ddayIds = manager.getAppWidgetIds(android.content.ComponentName(context, DDayWidgetProvider::class.java))
        DDayWidgetProvider().onUpdate(context, manager, ddayIds)
    }
}
